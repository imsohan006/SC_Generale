package com.employeeportal.config;

public class WebSecurityConfig  {
 
	/*
	 * @Override protected void configure(HttpSecurity http) throws Exception {
	 * http.cors().and() //other config }
	 * 
	 * @Bean CorsConfigurationSource corsConfigurationSource() { CorsConfiguration
	 * configuration = new CorsConfiguration();
	 * configuration.setAllowedOrigins(Arrays.asList("https://example.com"));
	 * configuration.setAllowedMethods(Arrays.asList("GET","POST"));
	 * UrlBasedCorsConfigurationSource source = new
	 * UrlBasedCorsConfigurationSource(); source.registerCorsConfiguration("/**",
	 * configuration); return source; }
	 */
}