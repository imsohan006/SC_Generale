package com.employeeportal.service;

import java.util.List;

import com.employeeportal.entity.Employee;

public interface EmployeeService {
	
    List<Employee> listAll();

    Employee saveOrUpdate(Employee employee);
}
