package com.employeeportal.application;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.employeeportal.entity.Employee;
import com.employeeportal.repository.EmployeeRepository;

@SpringBootTest
class EmployeePortalApplicationTests {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Test
	void contextLoads() {
	}

	@Test
    public void testAddEmployeeController() {
		Employee employee = new Employee("Sohan","Yadav","male","12/12/2019","CSE");
        Employee result = employeeRepository.save(employee);;
        assertEquals(employee, result);
     
    }
	
	@Test
    public void testAdd2EmployeeController() {
		Employee employee = new Employee("Apple","Yadav","male","12/12/2019","CSE");
        Employee result = employeeRepository.save(employee);;
        assertEquals(employee, result);
     
    }
	
	@Test
    public void testGetEmployeeController() {
        List<Employee> result1 = new ArrayList<Employee>();
        employeeRepository.findAll().forEach(result1::add);
        assertNotEquals(0, result1.size());
	}
}
