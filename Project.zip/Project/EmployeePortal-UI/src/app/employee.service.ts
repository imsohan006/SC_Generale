import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  private baseUrl : String = "http://localhost:8080/api"; 

  constructor(private http : HttpClient){}

  //add employee
  addEmployee(formData){
      const header = new HttpHeaders({
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'PUT, DELETE,GET'
      });
      return this.http.post(this.baseUrl+'/addemployee',formData,{headers: header});
  }

  //get employee list
  getEmployee(){
      return this.http.get(this.baseUrl+'/getemployee');
  };
}
