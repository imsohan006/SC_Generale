import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-employeeform',
  templateUrl: './employeeform.component.html',
  styleUrls: ['./employeeform.component.css']
})
export class EmployeeformComponent implements OnInit {

  userRegisterationForm : FormGroup;
  message : string;
  isRegistrationFailed : boolean = false;

  constructor(private fb : FormBuilder,
              private service : EmployeeService) { }

  ngOnInit() {

    this.userRegisterationForm = this.fb.group({
          firstname: [null, [Validators.required,Validators.pattern('[a-zA-Z ]+')]],
          lastname: [null, [Validators.required,Validators.pattern('[a-zA-Z ]+')]],
          gender: [null, [Validators.required,Validators.pattern('[a-zA-Z ]+')]],
          dob: [null, Validators.required],
          department: [null, [Validators.required,Validators.pattern('[a-zA-Z ]+')]]
      });
  }

  save(): void{
    var formData = {
      firstName:this.userRegisterationForm.value.firstname,
      lastName:this.userRegisterationForm.value.lastname,
      gender:this.userRegisterationForm.value.gender,
      dateOfBirth:this.userRegisterationForm.value.dob,
      department:this.userRegisterationForm.value.department
    };
    console.log(formData);
    
    this.service.addEmployee(formData).subscribe(
      data =>{
        alert("Employee information added succesfully");
    },
    error =>{
      alert("Sorry! Something went wrong");
    });
  }
}
